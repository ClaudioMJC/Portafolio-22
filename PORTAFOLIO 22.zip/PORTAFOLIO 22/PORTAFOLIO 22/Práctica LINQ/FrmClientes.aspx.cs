﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Práctica_LINQ
{
    public partial class FrmClientes : System.Web.UI.Page
    {
        private string lblMensaje = "";
        private void cargarGridTodosLosClientes()
        {
            BD_CAPASLINQDataContext DataContext = new BD_CAPASLINQDataContext();
            var consulta = from cliente in DataContext.CLIENTES
                           select cliente;

            grdCliente2.DataSource = consulta;
            grdCliente2.DataBind();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CargarDropDownClientes();
            }
        }

        private void CargarDropDownClientes()
        {
            BD_CAPASLINQDataContext DataContext = new BD_CAPASLINQDataContext();
            var clientes = from cliente in DataContext.CLIENTES
                           select new
                           {
                               ID_CLIENTE = cliente.ID_CLIENTE,
                               //NOMBRE = cliente.NOMBRE
                           };

            //ddlClientes.DataTextField = "NOMBRE";
            ddlClientes.DataTextField = "ID_CLIENTE";
            ddlClientes.DataValueField = "ID_CLIENTE"; 
            ddlClientes.DataSource = clientes;
            ddlClientes.DataBind();
        }


        protected void btnMostrar_Click(object sender, EventArgs e)
        {
            cargarGridTodosLosClientes();
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            int idCliente = ObtenerIdClienteSeleccionado();

            if (idCliente != -1)
            {
                if (ClienteTieneFacturas(idCliente))
                {
                    // Mostrar mensaje de error
                    lblMensaje = "No se puede eliminar el cliente porque tiene facturas asociadas.";
                }
                else
                {
                    // Proceder con la eliminación
                    EliminarCliente(idCliente);
                    lblMensaje = "Cliente eliminado correctamente.";
                }

                // Actualizar el GridView
                cargarGridTodosLosClientes();
            }
            else
            {
                // No se seleccionó ningún cliente, manejarlo según tus necesidades
                lblMensaje = "Selecciona un cliente para eliminar.";
            }
        }

        private bool ClienteTieneFacturas(int idCliente)
        {
            BD_CAPASLINQDataContext DataContext = new BD_CAPASLINQDataContext();
            var factura = DataContext.ENCABEZADO_FACTURA.FirstOrDefault(f => f.ID_CLIENTE == idCliente);

            return factura != null; // Si factura es null, el cliente no tiene facturas asociadas
        }


        private int ObtenerIdClienteSeleccionado()
        {
            if (grdCliente2.SelectedIndex >= 0)
            {
                return Convert.ToInt32(grdCliente2.DataKeys[grdCliente2.SelectedIndex].Value);
            }
            else
            {
                
                return -1; //regresa -1  indicando que no hay selección de cliente
            }
        }


        private void EliminarCliente(int idCliente)
        {
            BD_CAPASLINQDataContext DataContext = new BD_CAPASLINQDataContext();
            var cliente = DataContext.CLIENTES.FirstOrDefault(c => c.ID_CLIENTE == idCliente);

            if (cliente != null)
            {
                DataContext.CLIENTES.DeleteOnSubmit(cliente);
                DataContext.SubmitChanges();
            }
        }

        protected void grdCliente2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ObtenerIdClienteSeleccionado();
        }

        protected void btnEliminarDesdeDropDown_Click(object sender, EventArgs e)
        {
            int idCliente = Convert.ToInt32(ddlClientes.SelectedValue);

            if (ClienteTieneFacturas(idCliente))
            {
                lblMensaje = "No se puede eliminar el cliente porque tiene facturas asociadas.";
            }
            else
            {
                EliminarCliente(idCliente);
                CargarDropDownClientes(); // Actualizar la lista de clientes
                lblMensaje = "Cliente eliminado correctamente.";
            }

            // Actualizar el GridView
            cargarGridTodosLosClientes();
        }
    }
}