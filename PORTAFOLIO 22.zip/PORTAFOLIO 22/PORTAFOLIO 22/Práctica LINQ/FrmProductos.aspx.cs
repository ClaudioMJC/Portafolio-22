﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Práctica_LINQ
{
    public partial class FrmProductos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void cargarGridTodosLosProductos()
        {
            BD_CAPASLINQDataContext DataContext = new BD_CAPASLINQDataContext();
            var consulta = from producto in DataContext.PRODUCTOS
                           select producto;

            grdProductos.DataSource = consulta;
            grdProductos.DataBind();
        }

        protected void btnMostrar_Click(object sender, EventArgs e)
        {
            cargarGridTodosLosProductos();
        }
    }
}